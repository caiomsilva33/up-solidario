from django.apps import AppConfig


class OngsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ongs'
