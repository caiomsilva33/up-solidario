from django.contrib import admin
from .models import NGO

admin.site.register(NGO)